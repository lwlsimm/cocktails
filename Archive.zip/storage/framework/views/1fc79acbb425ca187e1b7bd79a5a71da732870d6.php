</body>
</html><?php /**PATH /Users/leesimmons/cocktails/resources/views/layouts/footer.blade.php ENDPATH**/ ?>