<nav class="navbar navbar-expand-lg bg-light">
    <div class="container row m-auto">
      <div class="col-8 d-flex flex-column text-center">
        <h1 class="nav-header mb-0">Cocktail Maker</h1>
        <p class="nav-tagline">Helping you make the perfect cocktail at home!</p>
      </div>
      <div class="col-4">
        <img src="<?php echo e(url('/img/cocktails.png')); ?>" alt="cocktail"/> 
      </div>
    </div>
  </nav><?php /**PATH /Users/leesimmons/cocktails/resources/views/layouts/nav.blade.php ENDPATH**/ ?>